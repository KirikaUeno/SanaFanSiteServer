package communication;

public interface CASListener {
    void messageFromServerRecieved(String message);
}
